from flask import Flask, render_template, request, jsonify
import sqlite3
import requests
from flask_caching import Cache
from config import QWEATHER_KEY

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
cache = Cache(app, config={'CACHE_TYPE': 'SimpleCache', 'CACHE_DEFAULT_TIMEOUT': 300})

# 初始化数据库
conn = sqlite3.connect('haze.db', check_same_thread=False)
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY,
        city TEXT NOT NULL,
        location_id TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
''')
conn.commit()


def get_location_id(city_name: str, adm: str = None) -> str:
    headers = {'Authorization': f'Bearer {QWEATHER_KEY}', 'Accept-Encoding': 'gzip'}
    params = {'location': city_name, 'adm': adm, 'number': 1}

    try:
        response = requests.get('https://geoapi.qweather.com/v2/city/lookup', headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        if data['code'] == '200' and data['location']:
            return data['location'][0]['id']
        raise ValueError(f"未找到城市: {city_name}")
    except Exception as e:
        raise RuntimeError(f"定位失败: {str(e)}")


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/locate', methods=['POST'])
def handle_location():
    try:
        city_name = request.json.get('city')
        if not city_name:
            return jsonify({'error': '城市参数缺失'}), 400

        location_id = get_location_id(city_name)
        cursor.execute('''
            INSERT INTO locations (city, location_id)
            SELECT ?, ? WHERE NOT EXISTS (
                SELECT 1 FROM locations WHERE location_id = ?
            )
        ''', (city_name, location_id, location_id))
        conn.commit()

        return jsonify({'status': 'success', 'city': city_name, 'location_id': location_id})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/air/<location_id>')
@cache.cached(timeout=300)
def get_air_quality(location_id: str):
    headers = {'Authorization': f'Bearer {QWEATHER_KEY}', 'Accept-Encoding': 'gzip'}

    try:
        response = requests.get('https://api.qweather.com/v7/air/now', headers=headers,
                                params={'location': location_id})
        response.raise_for_status()
        data = response.json()

        pm25_total = aqi_total = count = 0
        stations = data.get('station', []) + ([data['now']] if 'now' in data else [])
        for station in stations:
            pm25 = station.get('pm2p5', 0)
            aqi = station.get('aqi', 0)
            if pm25 and aqi:
                pm25_total += float(pm25)
                aqi_total += float(aqi)
                count += 1

        return jsonify({
            'pm25': round(pm25_total / count, 1) if count else 0,
            'aqi': round(aqi_total / count) if count else 0
        }) if count else jsonify({'error': '无数据'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/indices/<location_id>')
@cache.cached(timeout=3600)
def get_weather_indices(location_id: str):
    headers = {'Authorization': f'Bearer {QWEATHER_KEY}', 'Accept-Encoding': 'gzip'}

    try:
        response = requests.get('https://api.qweather.com/v7/indices/1d',
                                headers=headers,
                                params={'location': location_id, 'type': '1,3,8'})
        response.raise_for_status()
        indices = {item['type']: item for item in response.json().get('daily', [])}
        return jsonify(indices)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history')
def get_history():
    cursor.execute('SELECT city, location_id FROM locations ORDER BY timestamp DESC LIMIT 5')
    return jsonify([{'city': row[0], 'id': row[1]} for row in cursor.fetchall()])


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)