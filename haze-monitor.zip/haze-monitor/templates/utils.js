// 空气质量等级颜色映射
const aqiColorMap = {
    '1': '#00E400', '2': '#FFFF00', '3': '#FF7E00',
    '4': '#FF0000', '5': '#8F3F97', '6': '#7E0023'
};

// 生成指数卡片HTML
function buildIndexCard(type, data) {
    return `
    <div class="index-card">
        <h4>${data.name}</h4>
        <div class="level-badge" style="background:${aqiColorMap[data.level]}">
            ${data.category}
        </div>
        <p>${data.text}</p>
    </div>`;
}

// 更新空气质量数据展示
function updateAirQuality(pm25, aqi) {
    const aqiLevel = Math.min(Math.floor(aqi/50) + 1, 6);
    document.getElementById('aqi').innerHTML = `
        ${aqi} <span class="level-tag" style="background:${aqiColorMap[aqiLevel]}">
        ${['优','良','轻度','中度','重度','严重'][aqiLevel-1]}</span>
    `;
    document.getElementById('pm25').textContent = pm25;
}