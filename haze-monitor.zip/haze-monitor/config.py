# 百度地图 API 密钥
BAIDU_AK = 'your_baidu_ak_here'

# 和风天气 API 密钥
QWEATHER_KEY = '93834603ccfa4f5c9be767820d2f45a7'